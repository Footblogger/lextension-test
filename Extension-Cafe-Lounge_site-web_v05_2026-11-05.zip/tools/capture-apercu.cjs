// Médias pour la page d'aperçu client : node tools/capture-apercu.cjs <dossier>
const { chromium, devices } = require("playwright");
const out = process.argv[2];
const smoothScroll = (p, to, ms) => p.evaluate(([to, ms]) => new Promise((res) => {
  const y0 = scrollY, t0 = performance.now();
  const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
  const step = (t) => { const k = Math.min(1, (t - t0) / ms); scrollTo(0, y0 + (to - y0) * ease(k)); k < 1 ? requestAnimationFrame(step) : res(); };
  requestAnimationFrame(step);
}), [to, ms]);
const yOf = (p, sel) => p.evaluate((s) => document.querySelector(s).getBoundingClientRect().top + scrollY - 40, sel);
(async () => {
  const b = await chromium.launch();
  // 1. pleines pages
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const p = await ctx.newPage();
  for (const [u, n] of [["", "accueil"], ["menu/", "menu"], ["contact/", "contact"], ["en/", "accueil-en"]]) {
    await p.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await p.waitForTimeout(2600);
    const H = await p.evaluate(() => document.body.scrollHeight);
    for (let y = 0; y < H; y += 450) { await p.evaluate((y) => scrollTo(0, y), y); await p.waitForTimeout(110); }
    await p.evaluate(() => { document.querySelectorAll(".ink__w").forEach((w) => w.classList.add("on")); scrollTo(0, 0); });
    await p.waitForTimeout(900);
    await p.screenshot({ path: `${out}/raw/${n}-full.png`, fullPage: true });
    await p.screenshot({ path: `${out}/raw/${n}-top.png` });
  }
  await ctx.close();
  // 2. vidéo ordinateur
  const vd = await b.newContext({ viewport: { width: 1280, height: 800 }, recordVideo: { dir: `${out}/raw/vd`, size: { width: 1280, height: 800 } } });
  const v = await vd.newPage();
  await v.goto("http://localhost:8765/", { waitUntil: "load" }); await v.waitForTimeout(3600);
  for (const sel of [".manifesto", ".day", ".signature", ".reviews"]) { await smoothScroll(v, await yOf(v, sel), 1900); await v.waitForTimeout(1500); }
  await smoothScroll(v, 0, 1600); await v.waitForTimeout(600);
  await vd.close();
  // 3. vidéo mobile
  const vm = await b.newContext({ ...devices["iPhone 13"], recordVideo: { dir: `${out}/raw/vm`, size: { width: 390, height: 844 } } });
  const m = await vm.newPage();
  await m.goto("http://localhost:8765/", { waitUntil: "load" }); await m.waitForTimeout(3400);
  for (const sel of [".manifesto", ".day", ".signature", ".visit"]) { await smoothScroll(m, await yOf(m, sel), 1700); await m.waitForTimeout(1400); }
  await m.tap(".tabbar li:nth-child(1) a"); await m.waitForLoadState("load"); await m.waitForTimeout(2400);
  await smoothScroll(m, await yOf(m, "#cocktails"), 2200); await m.waitForTimeout(1500);
  await vm.close();
  await b.close();
})();
