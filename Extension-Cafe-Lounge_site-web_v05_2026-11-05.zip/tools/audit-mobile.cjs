// Audit mobile : captures réelles écran par écran — node tools/audit-mobile.cjs <url> <nom> [largeur]
const { chromium } = require("playwright");
(async () => {
  const [, , u, name, w] = process.argv;
  const width = Number(w) || 375, height = 667;
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width, height }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1" });
  const p = await ctx.newPage();
  await p.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await p.waitForTimeout(2600);
  const H = await p.evaluate(() => document.documentElement.scrollHeight);
  const step = height - 120; let i = 0;
  for (let y = 0; y < H - 40; y += step) {
    await p.evaluate((y) => window.scrollTo({ top: y, behavior: "instant" }), y); await p.waitForTimeout(700);
    await p.screenshot({ path: `scratch-shots/a-${name}-${String(i++).padStart(2, "0")}.png` });
  }
  console.log(name, "height", H, "screens", i);
  await b.close();
})();
