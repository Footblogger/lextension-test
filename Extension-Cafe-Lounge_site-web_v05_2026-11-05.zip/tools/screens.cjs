// Captures réelles du viewport mobile à des positions données : node tools/screens.cjs <url> <nom> <sel1,sel2,...>
const { chromium, devices } = require("playwright");
(async () => {
  const [, , u, name, sels] = process.argv;
  const b = await chromium.launch();
  const ctx = await b.newContext({ ...devices["iPhone 13"], deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  await p.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await p.waitForTimeout(2600);
  let i = 0;
  for (const sel of sels.split(",")) {
    if (sel !== "top") {
      const y = await p.evaluate((s) => document.querySelector(s).getBoundingClientRect().top + scrollY - 20, sel);
      await p.evaluate((y) => window.scrollTo({ top: y, behavior: "instant" }), y);
      await p.waitForTimeout(1400);
    }
    await p.screenshot({ path: `scratch-shots/${name}-${i++}.png` });
  }
  await b.close();
})();
