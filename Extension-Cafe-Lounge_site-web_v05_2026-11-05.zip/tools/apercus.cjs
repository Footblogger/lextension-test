// Aperçus haute résolution pour présentation — node tools/apercus.cjs <dossier>
const { chromium, devices } = require("playwright");
(async () => {
  const out = process.argv[2];
  const b = await chromium.launch();
  const d = await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const p = await d.newPage();
  await p.goto("http://localhost:8765/", { waitUntil: "networkidle" }); await p.waitForTimeout(3200);
  await p.screenshot({ path: `${out}/desk.png` });
  const m = await b.newContext({ ...devices["iPhone 13"] });
  const q = await m.newPage(); let i = 0;
  for (const [u, y] of [["", 0], ["", ".signature"], ["menu/", 0], ["contact/", 0]]) {
    await q.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await q.waitForTimeout(800);
    if (y) { const t = await q.evaluate((s) => document.querySelector(s).getBoundingClientRect().top + scrollY, y); for (let s = 0; s <= t; s += 300) { await q.evaluate((s) => scrollTo(0, s), s); await q.waitForTimeout(60); } await q.evaluate((t) => scrollTo(0, t), t); }
    await q.waitForTimeout(2600);
    await q.screenshot({ path: `${out}/m${i++}.png` });
  }
  await b.close();
})();
