// Captures d'écran et rendus d'icônes — usage : node tools/shot.cjs <mode>
const { chromium } = require("playwright");
const path = require("path");
const ROOT = path.resolve(__dirname, "..");
(async () => {
  const b = await chromium.launch();
  const mode = process.argv[2];
  if (mode === "icons") {
    const p = await b.newPage();
    const svg = "file://" + ROOT + "/src/assets/favicon.svg";
    for (const [n, s] of [["favicon-32.png", 32], ["apple-touch-icon.png", 180], ["icon-192.png", 192], ["icon-512.png", 512]]) {
      await p.setViewportSize({ width: s, height: s });
      await p.setContent(`<style>html,body{margin:0;background:${n.startsWith("apple") ? "#F5EBB5" : "transparent"}}</style><img src="${svg}" width="${s}" height="${s}">`);
      await p.waitForTimeout(150);
      await p.screenshot({ path: ROOT + "/src/assets/" + n, omitBackground: !n.startsWith("apple") });
    }
  }
  await b.close();
})();
