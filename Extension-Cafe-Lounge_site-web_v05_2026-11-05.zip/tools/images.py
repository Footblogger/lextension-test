"""Génère les variantes responsives (AVIF + WebP + JPEG de secours) à partir de src/originals.
Usage : python3 tools/images.py"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "originals"
OUT = ROOT / "src" / "assets" / "img"
OUT.mkdir(parents=True, exist_ok=True)

# nom -> (fichier source, largeurs, recadrage optionnel (gauche, haut, droite, bas) en ratio)
JOBS = {
    "facade-soir": ("facade-soir.webp", [480, 800, 1200], None),
    # recadrage 6:5 pour l'ouverture sur téléphone
    "facade-soir-mobile": ("facade-soir.webp", [480, 720, 960], (0.0, 0.167, 1.0, 1.0)),
}

for name, (src, widths, crop) in JOBS.items():
    im = Image.open(SRC / src).convert("RGB")
    if crop:
        w, h = im.size
        im = im.crop((int(crop[0]*w), int(crop[1]*h), int(crop[2]*w), int(crop[3]*h)))
    for wd in widths:
        if wd > im.width:
            wd = im.width
        ht = round(im.height * wd / im.width)
        r = im.resize((wd, ht), Image.LANCZOS)
        r.save(OUT / f"{name}-{wd}.avif", quality=52, speed=6)
        r.save(OUT / f"{name}-{wd}.webp", quality=74, method=6)
        r.save(OUT / f"{name}-{wd}.jpg", quality=78, optimize=True, progressive=True)
    print(name, im.size)
