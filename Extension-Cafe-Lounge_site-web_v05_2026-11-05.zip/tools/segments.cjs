// Captures mobiles par segments : node tools/segments.cjs <url> <nom> <nb>
const { chromium, devices } = require("playwright");
(async () => {
  const [, , u, name, n] = process.argv;
  const b = await chromium.launch();
  const ctx = await b.newContext({ ...devices["iPhone 13"], deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  await p.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await p.waitForTimeout(2600);
  const H = await p.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < H; y += 300) { await p.evaluate((y) => scrollTo(0, y), y); await p.waitForTimeout(80); }
  const vh = 844, count = Number(n) || Math.ceil(H / (vh * 2));
  for (let i = 0; i < count; i++) {
    const y = Math.round((H - vh * 2) * (count === 1 ? 0 : i / (count - 1)));
    await p.evaluate((y) => scrollTo(0, y), y); await p.waitForTimeout(1300);
    await p.screenshot({ path: `scratch-shots/${name}-${i}.png`, fullPage: true, clip: { x: 0, y, width: 390, height: vh * 2 } });
  }
  console.log(name, H, count);
  await b.close();
})();
