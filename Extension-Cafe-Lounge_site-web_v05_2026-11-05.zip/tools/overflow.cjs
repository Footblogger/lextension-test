const { chromium, devices } = require("playwright");
(async () => {
  const b = await chromium.launch();
  for (const [name, opts] of [["desktop", { viewport: { width: 1440, height: 900 } }], ["mobile", devices["iPhone 13"]]]) {
    const ctx = await b.newContext(opts); const p = await ctx.newPage();
    for (const u of process.argv.slice(2)) {
      await p.goto("http://localhost:8765/" + u, { waitUntil: "networkidle" }); await p.waitForTimeout(2500);
      const r = await p.evaluate(() => {
        const W = document.documentElement.clientWidth, out = [];
        document.querySelectorAll("body *").forEach((el) => {
          const b = el.getBoundingClientRect();
          if (b.right > W + 1 || b.left < -1) {
            // ignorer ce qui est dans un parent qui coupe le débordement
            let a = el.parentElement, clipped = false;
            while (a && a !== document.body) { const o = getComputedStyle(a); if (o.overflowX !== "visible" || o.overflow !== "visible") { clipped = true; break; } a = a.parentElement; }
            if (!clipped) out.push(el.className.baseVal ?? el.className + " " + Math.round(b.left) + "→" + Math.round(b.right));
          }
        });
        window.scrollTo(500, 0);
        return { list: [...new Set(out)].slice(0, 8), scrollX: window.scrollX };
      });
      console.log(name, u || "/", JSON.stringify(r));
    }
    await ctx.close();
  }
  await b.close();
})();
