// Tests d'interaction : node tools/interact.cjs
const { chromium, devices } = require("playwright");
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ ...devices["iPhone 13"], deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  const errs = []; p.on("pageerror", (e) => errs.push(e.message));
  await p.goto("http://localhost:8765/en/menu/", { waitUntil: "networkidle" }); await p.waitForTimeout(800);
  console.log("tab bar visible:", await p.isVisible(".tabbar"), "| current:", await p.textContent('.tabbar [aria-current="page"]'));
  await p.evaluate(() => document.getElementById("cocktails").scrollIntoView()); await p.waitForTimeout(900);
  console.log("active chip:", await p.evaluate(() => document.querySelector('[data-spy][aria-current="true"]').textContent));
  await p.goto("http://localhost:8765/contact/", { waitUntil: "networkidle" });
  await p.click("[data-map-load]"); await p.waitForTimeout(500);
  console.log("map iframe:", await p.locator(".map iframe").count());
  const d = await b.newContext({ viewport: { width: 1280, height: 800 } }); const q = await d.newPage();
  await q.goto("http://localhost:8765/", { waitUntil: "networkidle" });
  console.log("tab bar on desktop:", await q.isVisible(".tabbar"));
  // clavier : les premiers arrêts de tabulation
  const stops = [];
  for (let i = 0; i < 6; i++) { await q.keyboard.press("Tab"); stops.push(await q.evaluate(() => (document.activeElement.textContent || document.activeElement.getAttribute("aria-label") || "").trim().slice(0, 24))); }
  console.log("tab order:", stops.join(" | "));
  const rm = await b.newContext({ viewport: { width: 1280, height: 800 }, reducedMotion: "reduce" });
  const r = await rm.newPage(); await r.goto("http://localhost:8765/", { waitUntil: "networkidle" });
  console.log("reduced motion ink lit:", await r.evaluate(() => document.querySelectorAll(".ink__w.on").length + "/" + document.querySelectorAll(".ink__w").length));
  const nj = await b.newContext({ viewport: { width: 1280, height: 800 }, javaScriptEnabled: false });
  const s = await nj.newPage(); await s.goto("http://localhost:8765/", { waitUntil: "networkidle" });
  console.log("no-JS title visible:", await s.isVisible(".hero__title"));
  console.log("page errors:", errs.length ? errs : "none");
  await b.close();
})();
