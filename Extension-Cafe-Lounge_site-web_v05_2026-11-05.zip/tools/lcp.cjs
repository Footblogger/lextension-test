// Élément LCP et ressources (mobile, 4G lente, CPU x4) : node tools/lcp.cjs <url>
const { chromium, devices } = require("playwright");
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ ...devices["Pixel 7"] }); const p = await ctx.newPage();
  const cdp = await ctx.newCDPSession(p);
  await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 150, downloadThroughput: 1.6e6 / 8, uploadThroughput: 750e3 / 8 });
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
  await p.goto("http://localhost:8765/" + (process.argv[2] || ""));
  const r = await p.evaluate(() => new Promise((res) => {
    const out = [];
    new PerformanceObserver((l) => l.getEntries().forEach((e) => out.push(Math.round(e.startTime) + "ms " + (e.element ? e.element.tagName + "." + e.element.className : "?") + " size " + e.size))).observe({ type: "largest-contentful-paint", buffered: true });
    setTimeout(() => res({ lcp: out, res: performance.getEntriesByType("resource").map((x) => `${x.name.split("/").pop()} ${Math.round(x.startTime)}→${Math.round(x.responseEnd)}`) }), 4000);
  }));
  console.log(r.lcp.join("\n")); console.log(r.res.join("\n"));
  await b.close();
})();
