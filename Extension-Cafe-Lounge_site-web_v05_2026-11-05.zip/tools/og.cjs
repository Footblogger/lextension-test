const { chromium } = require("playwright");
const R = require("path").resolve(__dirname, "..");
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1200, height: 630 } });
  const { flower } = await import(R + "/src/lib.mjs");
  const css = require("fs").readFileSync(R + "/src/assets/css/main.css", "utf8").replace(/\.\.\/fonts\//g, "file://" + R + "/src/assets/fonts/");
  for (const [lang, t1, t2, sub] of [["fr", "Le prolongement", "de votre salon.", "Café · cocktails · mac & cheese — 200, rue Bernard O., Mile&nbsp;End"], ["en", "An extension", "of your living room.", "Coffee · cocktails · mac & cheese — 200 Bernard St. W., Mile&nbsp;End"]]) {
    const file = R + "/scratch-shots/og-" + lang + ".html";
    require("fs").writeFileSync(file, `<html><head><style>${css}
      body{margin:0;width:1200px;height:630px;overflow:hidden;background:var(--cream)}
      .og{display:grid;grid-template-columns:1fr 470px;height:630px}
      .l{padding:64px 56px;display:flex;flex-direction:column}
      .brand{align-self:flex-start}.brand__word{font-size:2.6rem}.brand__tag{font-size:.85rem}
      h1{font-family:var(--f-display);font-weight:560;font-size:82px;line-height:1;letter-spacing:-.03em;margin-top:auto}
      h1 em{font-style:italic;font-weight:420;color:var(--red)}
      p{margin-top:24px;font-size:22px;color:var(--ink-soft)}
      .r{position:relative;padding:40px 40px 0 0}.r .arch{height:590px;aspect-ratio:auto;border-radius:999px 999px 0 0}
      .f{position:absolute;left:-60px;bottom:30px;width:170px;background:var(--cream);border-radius:50%;padding:14px;box-shadow:var(--shadow)}
    </style></head><body><div class="og"><div class="l">
      <a class="brand"><span class="brand__word">L’extensi<svg class="mini-flower brand__o" viewBox="-50 -50 100 100"><g class="mini-flower__p">${Array.from({length:8},(_, k)=>`<ellipse cx="0" cy="-27" rx="13" ry="21" transform="rotate(${k*45})"/>`).join("")}</g><circle class="mini-flower__c" r="14"/></svg>n</span><span class="brand__tag">Café <i></i> Lounge</span></a>
      <h1>${t1}<br><em>${t2}</em></h1><p>${sub}</p></div>
      <div class="r"><div class="arch"><img src="file://${R}/src/assets/img/facade-soir-800.jpg" style="width:100%;height:100%;object-fit:cover"></div><div class="f">${flower({ id: "og" })}</div></div></div></body></html>`);
    await p.goto("file://" + file); await p.evaluate(() => document.fonts.ready);
    await p.waitForTimeout(500);
    await p.screenshot({ path: `${R}/src/assets/img/og-${lang}.jpg`, type: "jpeg", quality: 85 });
  }
  await b.close();
})();
