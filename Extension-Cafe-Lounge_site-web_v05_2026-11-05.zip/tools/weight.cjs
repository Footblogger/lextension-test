const { chromium, devices } = require("playwright");
(async () => {
  const b = await chromium.launch();
  for (const u of ["", "menu/", "contact/"]) {
    const ctx = await b.newContext({ ...devices["Pixel 7"] }); const p = await ctx.newPage();
    const cdp = await ctx.newCDPSession(p);
    await cdp.send("Network.enable");
    await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 150, downloadThroughput: 1.6e6 / 8, uploadThroughput: 750e3 / 8 });
    await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
    let bytes = 0, n = 0;
    cdp.on("Network.loadingFinished", (e) => { bytes += e.encodedDataLength; n++; });
    const t0 = Date.now();
    await p.goto("http://localhost:8765/" + u, { waitUntil: "load" });
    const load = Date.now() - t0;
    const m = await p.evaluate(() => new Promise((res) => {
      let lcp = 0, cls = 0;
      new PerformanceObserver((l) => l.getEntries().forEach((e) => (lcp = e.startTime))).observe({ type: "largest-contentful-paint", buffered: true });
      new PerformanceObserver((l) => l.getEntries().forEach((e) => { if (!e.hadRecentInput) cls += e.value; })).observe({ type: "layout-shift", buffered: true });
      setTimeout(() => res({ lcp: Math.round(lcp), cls: cls.toFixed(3) }), 3500);
    }));
    console.log(`/${u}  requests:${n}  transfer:${(bytes / 1024).toFixed(0)} KB  load:${load} ms  LCP:${m.lcp} ms  CLS:${m.cls}  (Slow 4G, CPU x4)`);
    await ctx.close();
  }
  await b.close();
})();
