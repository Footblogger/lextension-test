// Revue visuelle : node tools/review.cjs <url-path> <nom> [mobile]
const { chromium, devices } = require("playwright");
(async () => {
  const [, , urlPath, name, mobile] = process.argv;
  const b = await chromium.launch();
  const ctx = mobile ? await b.newContext({ ...devices["iPhone 13"] }) : await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  const errors = [];
  p.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  p.on("pageerror", (e) => errors.push(e.message));
  await p.goto("http://localhost:8765/" + urlPath, { waitUntil: "networkidle" });
  await p.waitForTimeout(2600);
  await p.screenshot({ path: `scratch-shots/${name}-fold.png` });
  // défiler pour déclencher les apparitions
  const h = await p.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < h; y += 400) { await p.evaluate((y) => window.scrollTo(0, y), y); await p.waitForTimeout(120); }
  await p.waitForTimeout(1200);
  await p.evaluate(() => window.scrollTo(0, 0));
  await p.waitForTimeout(500);
  await p.screenshot({ path: `scratch-shots/${name}-full.png`, fullPage: true });
  const overflow = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  console.log(name, "errors:", errors.length ? errors : "none", "| h-overflow:", overflow);
  await b.close();
})();
