import { menu, site } from "../data.mjs";
import { routes, href, icon, price, esc } from "../lib.mjs";
import { pageHero } from "./partials.mjs";

const TAGS = {
  v: { fr: ["V", "Végétarien"], en: ["V", "Vegetarian"] },
  vg: { fr: ["VG", "Végane"], en: ["VG", "Vegan"] },
  sg: { fr: ["SG", "Sans gluten"], en: ["GF", "Gluten-free"] },
};

export default function menuPage(lang, path) {
  const L = (fr, en) => (lang === "fr" ? fr : en);
  const anchor = (c) => (lang === "fr" ? c.id : { cafe: "coffee", the: "tea", bieres: "beer", midi: "lunch", "petites-faims": "snacks", sucre: "sweets" }[c.id] || c.id);

  const chips = menu
    .map((c, i) => `<li><a class="chip" href="#${anchor(c)}" data-spy="${anchor(c)}"${i === 0 ? ' aria-current="true"' : ""}>${c[lang].title}</a></li>`)
    .join("");

  const sections = menu
    .map((c, ci) => {
      const items = c.items
        .map((it) => {
          const [name, desc] = it[lang];
          const tags = (it.tags || []).filter((t) => TAGS[t]);
          const sig = (it.tags || []).includes("sig");
          const tagHtml = tags.map((t) => ` <abbr class="tag" title="${TAGS[t][lang][1]}">${TAGS[t][lang][0]}</abbr>`).join("");
          return `<li class="item${sig ? " item--sig" : ""}">
  <div class="item__row">
    <h3 class="item__name">${esc(name)}${sig ? `<span class="item__sig">${L("Signature", "Signature")}</span>` : ""}${!desc ? tagHtml : ""}</h3>
    <span class="item__dots" aria-hidden="true"></span>
    <span class="item__price">${price(it.price, lang)}</span>
  </div>
  ${desc ? `<p class="item__desc">${esc(desc)}${tagHtml}</p>` : ""}
</li>`;
        })
        .join("");
      return `<section class="mcat" id="${anchor(c)}" aria-labelledby="${anchor(c)}-t">
  <header class="mcat__head">
    <h2 class="mcat__t" id="${anchor(c)}-t">${c[lang].title}</h2>
    ${c[lang].note ? `<p class="mcat__note">${c[lang].note}</p>` : ""}
  </header>
  <ul class="mcat__list" role="list">${items}</ul>
</section>`;
    })
    .join("");

  const legend = Object.values(TAGS)
    .map((t) => `<li><abbr class="tag" title="${t[lang][1]}">${t[lang][0]}</abbr> ${t[lang][1]}</li>`)
    .join("");

  const body = `
${pageHero({
  eyebrow: L("Menu", "Menu"),
  title: L("Bien manger, *bien boire.*", "Eat well, *drink well.*"),
  lead: L(
    "Du premier espresso au dernier cocktail, une carte courte et généreuse, préparée sur place avec des produits d’ici autant que possible.",
    "From the first espresso to the last cocktail: a short, generous menu made in-house with local products whenever possible."
  ),
  flowerId: "fpm",
})}

<nav class="menu-nav" aria-label="${L("Catégories du menu", "Menu categories")}" data-menunav>
  <div class="wrap"><ul class="menu-nav__list" role="list">${chips}</ul></div>
</nav>

<div class="section section--tight">
  <div class="wrap menu-grid">
    ${sections}
  </div>
  <div class="wrap menu-foot">
    <ul class="legend" role="list">${legend}</ul>
    <p>${L(
      "Taxes en sus. Les prix et les plats peuvent changer selon les saisons et les arrivages. Allergies ou restrictions ? Parlez-en à notre équipe, on s’adapte avec plaisir.",
      "Taxes extra. Prices and dishes may change with the seasons. Allergies or dietary needs? Let our team know, we’re happy to adapt."
    )}</p>
    <p>${L("Vous venez en groupe de plus de huit personnes ? Appelez-nous au", "Coming with a group of more than eight? Call us at")} <a class="link" href="tel:${site.phone}">${site.phoneDisplay}</a>.</p>
  </div>
</div>`;

  return {
    title: L("Menu : café, cocktails, mac & cheese", "Menu: coffee, cocktails, mac & cheese"),
    description: L(
      "Le menu de L’Extension Café Lounge : cafés de spécialité, thés, cocktails, mocktails, bières du Québec, déjeuners, le fameux mac & cheese et douceurs maison.",
      "L’Extension Café Lounge menu: specialty coffee, tea, cocktails, mocktails, Québec beer, lunch, the famous mac & cheese and house-made treats."
    ),
    body,
  };
}
