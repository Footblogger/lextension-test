import { site } from "../data.mjs";
import { icon, mapsLink, mapsEmbed, splitTitle, miniFlower, flower } from "../lib.mjs";

/** Badge « Ouvert maintenant », rempli par JS selon l'heure de Montréal. */
export const statusBadge = () => `<p class="status" data-status hidden></p>`;

/** Étoiles (remplissage partiel selon la note). */
export function ratingStars(lang, value = 4.7) {
  const pct = Math.round((value / 5) * 100);
  const star = icon("star", { size: 16 });
  const label = lang === "fr" ? `Note de ${String(value).replace(".", ",")} sur 5` : `Rated ${value} out of 5`;
  return `<span class="stars" role="img" aria-label="${label}"><span class="stars__bg">${star.repeat(5)}</span><span class="stars__fg" style="width:${pct}%">${star.repeat(5)}</span></span>`;
}

/**
 * Carte Google Maps chargée seulement sur demande (performance + Loi 25 :
 * aucune donnée n'est envoyée à Google avant le clic du visiteur).
 */
export function mapBlock(lang) {
  const L = (fr, en) => (lang === "fr" ? fr : en);
  return `<div class="map" data-map data-src="${mapsEmbed()}" data-title="${L("Carte : L’Extension Café Lounge, 200, rue Bernard Ouest", "Map: L’Extension Café Lounge, 200 Bernard St. West")}">
  <div class="map__facade">
    <svg class="map__streets" viewBox="0 0 400 300" aria-hidden="true" focusable="false" preserveAspectRatio="xMidYMid slice">
      <g fill="none" stroke-linecap="round">
        <path class="map__road map__road--main" d="M-20 168 L420 132"/>
        <path class="map__road" d="M70 -20 L110 320"/>
        <path class="map__road" d="M190 -20 L222 320"/>
        <path class="map__road" d="M305 -20 L332 320"/>
        <path class="map__road map__road--thin" d="M-20 70 L420 38"/>
        <path class="map__road map__road--thin" d="M-20 262 L420 228"/>
      </g>
      <text class="map__label" x="236" y="128" transform="rotate(-4.7 236 128)">${L("rue Bernard O.", "Bernard St. W.")}</text>
    </svg>
    <div class="map__pin">${miniFlower("map__pinflower")}<span class="map__pulse" aria-hidden="true"></span></div>
    <div class="map__card">
      <p class="map__name">L’Extension Café Lounge</p>
      <p>${lang === "fr" ? site.address.street : site.address.streetEn}, ${site.address.city}</p>
      <div class="map__btns">
        <button class="btn btn--primary btn--sm" type="button" data-map-load>${icon("pin", { size: 16 })}<span>${L("Afficher la carte", "Show map")}</span></button>
        <a class="btn btn--ghost btn--sm map__ext" href="${mapsLink()}" target="_blank" rel="noopener"><span>${L("Ouvrir dans Google Maps", "Open in Google Maps")}</span>${icon("external", { size: 14 })}</a>
      </div>
      <p class="map__note">${L("La carte interactive est fournie par Google et ne se charge qu’après votre clic.", "The interactive map is provided by Google and only loads after you click.")}</p>
    </div>
  </div>
</div>`;
}

/** En-tête de page intérieure. */
export function pageHero({ eyebrow, title, lead, flowerId = "fp", extra = "" }) {
  return `<section class="phero">
  <div class="wrap phero__inner">
    <p class="eyebrow phero__eyebrow">${miniFlower("eyebrow__f")} ${eyebrow}</p>
    ${splitTitle(title, { cls: "phero__title display" })}
    ${lead ? `<p class="lead phero__lead">${lead}</p>` : ""}
    ${extra}
  </div>
  <div class="phero__flower" aria-hidden="true">${flower({ bloom: true, id: flowerId })}</div>
</section>`;
}
