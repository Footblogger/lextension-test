import { icon, flower } from "../lib.mjs";

// Page 404 bilingue (liens absolus : elle peut être servie à n'importe quelle adresse).
export default function notFound() {
  const body = `
<section class="nf">
  <div class="wrap nf__inner">
    <div class="nf__flower">${flower({ bloom: true, spin: true, id: "f404" })}</div>
    <p class="eyebrow">Erreur 404</p>
    <h1 class="display nf__t">Cette page a pris <em>une pause café.</em></h1>
    <p class="lead">La page que vous cherchez n’existe pas ou a été déplacée.</p>
    <p class="lead nf__en" lang="en-CA">This page is on a coffee break. The page you’re looking for doesn’t exist or has moved.</p>
    <div class="hero__ctas">
      <a class="btn btn--primary" href="/"><span>Retour à l’accueil</span>${icon("arrow", { size: 18 })}</a>
      <a class="btn btn--ghost" href="/en/" lang="en-CA"><span>English home</span></a>
    </div>
  </div>
</section>`;
  return { title: "Page introuvable", description: "Cette page est introuvable.", body };
}
