import { site, reviews } from "../data.mjs";
import { routes, href, icon, splitTitle, inkWords, flower, miniFlower, picture, ringText, hoursTable, mapsLink } from "../lib.mjs";
import { mapBlock, statusBadge, ratingStars } from "./partials.mjs";

export default function home(lang, path) {
  const L = (fr, en) => (lang === "fr" ? fr : en);
  const h = (k) => href(path, routes[k][lang]);

  const marqueeWords = L(
    ["Café", "Thé", "Cocktails", "Mocktails", "Bières d’ici", "Mac & cheese", "Goûter", "5 à 7", "Mile End"],
    ["Coffee", "Tea", "Cocktails", "Mocktails", "Local beer", "Mac & cheese", "Treats", "Happy hour", "Mile End"]
  );
  const marqueeRow = marqueeWords.map((w) => `<span>${w}</span>${miniFlower("marquee__f")}`).join("");

  const dayparts = [
    { t: "9 h", te: "9 a.m.", icon: "sun", fr: ["Le matin", "Espresso, latte à l’érable et croissant chaud pour bien partir la journée."], en: ["Morning", "Espresso, maple latte and a warm croissant to start the day right."] },
    { t: "12 h", te: "Noon", icon: "utensils", fr: ["Le midi", "Le fameux mac & cheese, des bols de saison et un grilled cheese bien doré."], en: ["Lunch", "The famous mac & cheese, seasonal bowls and a golden grilled cheese."] },
    { t: "15 h", te: "3 p.m.", icon: "cookie", fr: ["Le goûter", "Chaï, matcha et pouding chômeur : la pause qui fait du bien."], en: ["Afternoon", "Chai, matcha and pouding chômeur: the break you deserve."] },
    { t: "17 h", te: "5 p.m.", icon: "wine", fr: ["Le 5 à 7", "Cocktails, mocktails et bières d’ici, à partager entre amis."], en: ["Happy hour", "Cocktails, mocktails and local beer to share with friends."] },
  ];

  const values = [
    { icon: "leaf", fr: ["Éthique", "Des produits choisis avec soin, des fournisseurs responsables et le moins de gaspillage possible."], en: ["Ethical", "Carefully chosen products, responsible suppliers and as little waste as possible."] },
    { icon: "users", fr: ["Communautaire", "Un lieu de rencontre pour les voisins, les artistes, les étudiants et les télétravailleurs du quartier."], en: ["Community", "A meeting place for neighbours, artists, students and remote workers from the area."] },
    { icon: "coffee", fr: ["Convivial", "Des fauteuils, des livres, de la lumière chaude et une équipe qui vous reconnaît."], en: ["Welcoming", "Armchairs, books, warm light and a team that remembers you."] },
  ];

  const body = `
<section class="hero">
  <div class="wrap hero__grid">
    <div class="hero__copy">
      <p class="eyebrow hero__eyebrow">${miniFlower("eyebrow__f")} ${L("Café · Lounge — Mile End, Montréal", "Café · Lounge — Mile End, Montréal")}</p>
      ${splitTitle(L("Le prolongement de *votre salon.*", "An extension of *your living room.*"), { cls: "hero__title display" })}
      <p class="lead hero__lead"><span class="lead__long">${L(
        "Un espace éthique, communautaire et convivial où l’on vient pour un espresso le matin, un mac & cheese le midi et un cocktail quand le soleil descend sur la rue Bernard.",
        "An ethical, community-minded and welcoming space for a morning espresso, a mac & cheese at lunch and a cocktail as the sun sets over rue Bernard."
      )}</span><span class="lead__short">${L("Café le jour, lounge le soir, au cœur du Mile End.", "Café by day, lounge by night, in the heart of Mile End.")}</span></p>
      <div class="hero__ctas">
        <a class="btn btn--primary" href="${h("menu")}"><span>${L("Voir le menu", "See the menu")}</span>${icon("arrow", { size: 18 })}</a>
        <a class="btn btn--ghost hero__find" href="#visiter"><span>${L("Nous trouver", "Find us")}</span></a>
      </div>
      <div class="hero__meta">
        ${statusBadge()}
        <a class="hero__rating" href="${mapsLink()}" target="_blank" rel="noopener">
          ${ratingStars(lang)}
          <span><strong>${L(site.rating.value, site.rating.valueEn)}</strong> · ${site.rating.count} ${L("avis Google", "Google reviews")}</span>
        </a>
      </div>
    </div>
    <div class="hero__visual">
      <div class="arch hero__arch">
        ${picture(path, "facade-soir", [480, 800, 1200], {
          alt: L("La façade vitrée de L’Extension le soir, ornée de grandes fleurs rétro et baignée de lumière ambrée", "L’Extension’s glass storefront at dusk, decorated with large retro flowers and glowing with amber light"),
          sizes: "(min-width: 960px) 44vw, 92vw",
          eager: true,
          ratio: [1200, 1200],
          art: { name: "facade-soir-mobile", widths: [480, 720, 960], media: "(max-width: 959px)", sizes: "calc(100vw - 32px)" },
          cls: "arch__img",
        })}
      </div>
      <div class="hero__badge">
        ${ringText(L("café · lounge · mile end · montréal · ", "café · lounge · mile end · montréal · "), "ring-hero")}
        ${flower({ bloom: true, id: "fh", cls: "hero__flower" })}
      </div>
    </div>
  </div>
</section>

<div class="marquee-clip"><div class="marquee" aria-hidden="true">
  <div class="marquee__track"><div class="marquee__row">${marqueeRow}</div><div class="marquee__row">${marqueeRow}</div></div>
</div></div>

<section class="section manifesto" aria-labelledby="manifesto-t">
  <div class="wrap">
    <h2 class="eyebrow" id="manifesto-t">${L("L’esprit de la maison", "The spirit of the place")}</h2>
    <p class="ink" data-ink>${inkWords(L(
      "Ici, on prend le temps. Un café préparé avec soin, des produits choisis de façon responsable et une grande table où voisins, artistes, étudiants et télétravailleurs se croisent comme à la maison. L’Extension, c’est la pièce de plus que le Mile End attendait.",
      "Here, we take our time. Coffee made with care, responsibly sourced products and a big table where neighbours, artists, students and remote workers meet as if at home. L’Extension is the extra room Mile End was waiting for."
    ))}</p>
    <ul class="values" role="list">
      ${values.map((v) => `<li class="value">
        <span class="value__icon">${icon(v.icon, { size: 26 })}</span>
        <h3 class="value__t">${v[lang][0]}</h3>
        <p>${v[lang][1]}</p>
      </li>`).join("")}
    </ul>
  </div>
</section>

<section class="section day" aria-labelledby="day-t">
  <div class="wrap">
    <div class="section__head">
      <p class="eyebrow">${L("Du matin au soir", "Morning to night")}</p>
      <h2 class="h2" id="day-t">${L("Du premier café au dernier verre.", "From the first coffee to the last drink.")}</h2>
    </div>
    <ol class="day__list" role="list" tabindex="0" aria-label="${L("Les moments de la journée", "Moments of the day")}">
      ${dayparts.map((d, i) => `<li class="daycard daycard--${i + 1}">
        <div class="daycard__top"><span class="daycard__time">${L(d.t, d.te)}</span>${icon(d.icon, { size: 28 })}</div>
        <h3 class="daycard__t">${d[lang][0]}</h3>
        <p>${d[lang][1]}</p>
      </li>`).join("")}
    </ol>
  </div>
</section>

<section class="section signature" aria-labelledby="sig-t">
  <div class="wrap signature__grid">
    <div class="signature__art">
      <div class="signature__disc">
        ${ringText(L("signature de la maison · servi toute la journée · ", "house signature · served all day long · "), "ring-sig")}
        <span class="signature__mac">Mac<br><em>&amp;</em><br>cheese</span>
      </div>
    </div>
    <div class="signature__copy">
      <p class="eyebrow eyebrow--light">${L("Le plat dont tout le monde parle", "The dish everyone talks about")}</p>
      <h2 class="h2" id="sig-t">${L("Trois fromages d’ici, <em>une chapelure dorée.</em>", "Three local cheeses, <em>one golden crumb.</em>")}</h2>
      <p>${L(
        "Crémeux, gratiné, réconfortant : notre mac & cheese est devenu la raison pour laquelle bien des voisins poussent la porte. Version classique ou gratinée au bacon, servi midi et soir.",
        "Creamy, golden and comforting: our mac & cheese has become the reason many neighbours walk through the door. Classic or extra gratiné with bacon, served lunch and dinner."
      )}</p>
      <figure class="quote">
        <blockquote><p>« ${L(reviews[1].fr, reviews[1].en)} »</p></blockquote>
        <figcaption>${reviews[1].author} · ${L("avis Google, traduit de l’anglais", "Google review")}</figcaption>
      </figure>
      <a class="btn btn--light" href="${h("menu")}#${L("midi", "lunch")}"><span>${L("Découvrir le menu du midi", "Explore the lunch menu")}</span>${icon("arrow", { size: 18 })}</a>
    </div>
  </div>
</section>

<section class="section reviews" aria-labelledby="rev-t">
  <div class="wrap">
    <div class="reviews__head">
      <div>
        <p class="eyebrow">${L("Ce qu’en disent nos voisins", "What our neighbours say")}</p>
        <h2 class="h2" id="rev-t">${L("Un salon qu’on recommande.", "A living room people recommend.")}</h2>
      </div>
      <div class="score">
        <span class="score__n">${L(site.rating.value, site.rating.valueEn)}</span>
        <span class="score__meta">${ratingStars(lang)}<span>${site.rating.count} ${L("avis sur Google", "reviews on Google")}</span></span>
      </div>
    </div>
    <ul class="reviews__list" role="list" tabindex="0" aria-label="${L("Avis Google", "Google reviews")}">
      ${reviews.map((r) => `<li class="review">
        <figure>
          ${ratingStars(lang, 5)}
          <blockquote><p>${L(r.fr, r.en)}</p></blockquote>
          <figcaption><span class="review__avatar" aria-hidden="true">${r.author[0]}</span><span>${r.author}${lang === "fr" && r.original === "en" ? `<small>${L("Traduit de l’anglais", "")}</small>` : ""}</span></figcaption>
        </figure>
      </li>`).join("")}
    </ul>
    <p class="reviews__more"><a class="link" href="${mapsLink()}" target="_blank" rel="noopener">${L("Lire tous les avis sur Google", "Read all reviews on Google")} ${icon("external", { size: 16 })}</a></p>
  </div>
</section>

<section class="section visit" id="visiter" aria-labelledby="visit-t">
  <div class="wrap visit__grid">
    <div class="visit__info">
      <p class="eyebrow">${L("Passez nous voir", "Come say hi")}</p>
      <h2 class="addr" id="visit-t"><span class="addr__n">200</span><span class="addr__s">${L("rue Bernard Ouest", "Bernard Street West")}<small>Mile End · ${site.address.city} (${site.address.region}) ${site.address.postal}</small></span></h2>
      <div class="visit__cols">
        <div>
          <h3 class="label">${icon("clock", { size: 18 })}${L("Heures d’ouverture", "Opening hours")}</h3>
          ${hoursTable(lang)}
          ${statusBadge()}
        </div>
        <div class="visit__contact">
          <h3 class="label">${icon("phone", { size: 18 })}${L("Téléphone", "Phone")}</h3>
          <p><a class="link" href="tel:${site.phone}">${site.phoneDisplay}</a></p>
          <h3 class="label">${icon("instagram", { size: 18 })}Instagram</h3>
          <p><a class="link" href="${site.instagram}" target="_blank" rel="noopener">${site.instagramHandle}</a></p>
          <p class="small">${L("Nouveautés, soirées et plats du jour.", "New drinks, events and daily specials.")}</p>
          <div class="visit__btns">
            <a class="btn btn--primary btn--sm" href="${mapsLink()}" target="_blank" rel="noopener">${icon("pin", { size: 16 })}<span>${L("Itinéraire", "Directions")}</span></a>
            <a class="btn btn--ghost btn--sm" href="tel:${site.phone}">${icon("phone", { size: 16 })}<span>${L("Appeler", "Call")}</span></a>
          </div>
        </div>
      </div>
    </div>
    <div class="visit__map">${mapBlock(lang)}</div>
  </div>
</section>`;

  return {
    title: L("L’Extension Café Lounge — Café, cocktails et mac & cheese dans le Mile End, Montréal", "L’Extension Café Lounge — Coffee, cocktails & mac and cheese in Mile End, Montréal"),
    description: L(
      "Café lounge éthique, communautaire et convivial du Mile End : café, thé, cocktails, mocktails, bières d’ici et le fameux mac & cheese. 200, rue Bernard Ouest, Montréal.",
      "Ethical, community-minded café lounge in Mile End: coffee, tea, cocktails, mocktails, local beer and the famous mac & cheese. 200 Bernard St. West, Montréal."
    ),
    body,
  };
}
