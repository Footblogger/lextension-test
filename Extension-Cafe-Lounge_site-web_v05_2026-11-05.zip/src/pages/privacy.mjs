import { site } from "../data.mjs";
import { routes, href } from "../lib.mjs";
import { pageHero } from "./partials.mjs";

// À VALIDER par le propriétaire (Loi 25 — Québec) : responsable.
export default function privacy(lang, path) {
  const L = (fr, en) => (lang === "fr" ? fr : en);
  const contactLine = `${site.legalName}, ${lang === "fr" ? site.address.street : site.address.streetEn}, ${site.address.city} (${site.address.region}) ${site.address.postal} · ${site.phoneDisplay}${site.email ? " · " + site.email : ""}`;

  const fr = `
<h2>1. Notre engagement</h2>
<p>L’Extension Café Lounge respecte votre vie privée et protège vos renseignements personnels conformément à la <em>Loi sur la protection des renseignements personnels dans le secteur privé</em> du Québec (incluant les modifications de la Loi 25).</p>
<h2>2. Responsable de la protection des renseignements personnels</h2>
<p>La personne responsable est la direction de L’Extension Café Lounge. Pour toute question, demande d’accès ou de rectification, ou pour retirer votre consentement : ${contactLine}.</p>
<h2>3. Renseignements recueillis</h2>
<p>Ce site ne crée pas de compte, ne contient aucun formulaire, n’utilise aucun témoin (cookie) publicitaire et n’intègre aucun outil de suivi. Il ne recueille donc aucun renseignement personnel à votre sujet.</p>
<h2>4. Services de tiers</h2>
<p>La carte interactive Google Maps ne se charge que si vous cliquez sur « Afficher la carte ». Google peut alors recueillir des données selon sa propre politique de confidentialité. Les liens vers Instagram et Google Maps vous mènent vers ces services, qui appliquent leurs propres politiques.</p>
<h2>5. Vos droits</h2>
<p>Si vous nous communiquez des renseignements personnels par téléphone ou en personne, vous pouvez en tout temps en demander l’accès, la rectification ou la suppression en communiquant avec la personne responsable ci-dessus. Vous pouvez également déposer une plainte auprès de la Commission d’accès à l’information du Québec.</p>
<h2>6. Mise à jour</h2>
<p>Cette politique peut être mise à jour. La version en vigueur est toujours publiée sur cette page.</p>`;

  const en = `
<h2>1. Our commitment</h2>
<p>L’Extension Café Lounge respects your privacy and protects your personal information in accordance with Québec’s <em>Act respecting the protection of personal information in the private sector</em> (as amended by Law 25).</p>
<h2>2. Person in charge of personal information</h2>
<p>The person in charge is the management of L’Extension Café Lounge. For any question, request for access or correction, or to withdraw your consent: ${contactLine}.</p>
<h2>3. Information we collect</h2>
<p>This website does not create accounts, has no forms, uses no advertising cookies and includes no tracking tools. It therefore collects no personal information about you.</p>
<h2>4. Third-party services</h2>
<p>The interactive Google Map only loads if you click “Show map”. Google may then collect data under its own privacy policy. Links to Instagram and Google Maps take you to those services, which apply their own policies.</p>
<h2>5. Your rights</h2>
<p>If you share personal information with us by phone or in person, you may at any time request access to, correction or deletion of it by contacting the person in charge above. You may also file a complaint with the Commission d’accès à l’information du Québec.</p>
<h2>6. Updates</h2>
<p>This policy may be updated. The current version is always published on this page.</p>`;

  const body = `
${pageHero({
  eyebrow: L("Confidentialité", "Privacy"),
  title: L("Politique de *confidentialité.*", "Privacy *policy.*"),
  lead: L("Dernière mise à jour : 5 novembre 2026", "Last updated: November 5, 2026"),
  flowerId: "fpp",
})}
<section class="section section--tight">
  <div class="wrap prose">${L(fr, en)}
    <p><a class="link" href="${href(path, routes.home[lang])}">${L("← Retour à l’accueil", "← Back to home")}</a></p>
  </div>
</section>`;

  return {
    title: L("Politique de confidentialité", "Privacy policy"),
    description: L(
      "Comment L’Extension Café Lounge protège vos renseignements personnels, conformément à la Loi 25 du Québec.",
      "How L’Extension Café Lounge protects your personal information, in accordance with Québec’s Law 25."
    ),
    body,
  };
}
