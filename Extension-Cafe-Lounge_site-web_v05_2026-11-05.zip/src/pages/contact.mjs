import { site } from "../data.mjs";
import { icon, hoursTable, mapsLink } from "../lib.mjs";
import { pageHero, mapBlock, statusBadge } from "./partials.mjs";

export default function contact(lang, path) {
  const L = (fr, en) => (lang === "fr" ? fr : en);

  const cards = [
    {
      icon: "pin",
      t: L("Adresse", "Address"),
      body: `${lang === "fr" ? site.address.street : site.address.streetEn}<br>${site.address.city} (${site.address.region}) ${site.address.postal}`,
      link: [mapsLink(), L("Obtenir l’itinéraire", "Get directions"), true],
    },
    {
      icon: "phone",
      t: L("Téléphone", "Phone"),
      body: site.phoneDisplay,
      link: [`tel:${site.phone}`, L("Appeler maintenant", "Call now"), false],
    },
    {
      icon: "instagram",
      t: "Instagram",
      body: site.instagramHandle,
      link: [site.instagram, L("Nous suivre", "Follow us"), true],
    },
  ];
  if (site.email) {
    cards.push({ icon: "mail", t: L("Courriel", "Email"), body: site.email, link: [`mailto:${site.email}`, L("Nous écrire", "Write to us"), false] });
  }

  const body = `
${pageHero({
  eyebrow: L("Contact", "Contact"),
  title: L("Venez *comme vous êtes.*", "Come *as you are.*"),
  lead: L(
    "Pas besoin de réserver pour un café : poussez la porte, on vous garde une place au chaud. Pour un groupe, un simple appel suffit.",
    "No reservation needed for a coffee: just walk in, we’ll keep a warm seat for you. For groups, a quick call is all it takes."
  ),
  flowerId: "fpc",
  extra: statusBadge(),
})}

<section class="section section--tight" aria-label="${L("Coordonnées", "Contact details")}">
  <div class="wrap">
    <ul class="cards" role="list">
      ${cards.map((c, i) => `<li class="card">
        <span class="card__icon">${icon(c.icon, { size: 24 })}</span>
        <h2 class="card__t">${c.t}</h2>
        <p class="card__body">${c.body}</p>
        <a class="link card__link" href="${c.link[0]}"${c.link[2] ? ' target="_blank" rel="noopener"' : ""}>${c.link[1]} ${icon(c.link[2] ? "external" : "arrow", { size: 16 })}</a>
      </li>`).join("")}
    </ul>
  </div>
</section>

<section class="section visit visit--contact" aria-labelledby="hours-t">
  <div class="wrap visit__grid">
    <div class="visit__info">
      <p class="eyebrow">${L("Heures d’ouverture", "Opening hours")}</p>
      <h2 class="h2" id="hours-t">${L("Du matin jusqu’au soir.", "From morning until night.")}</h2>
      ${hoursTable(lang)}
      <p class="small">${L("Les heures peuvent varier les jours fériés. Consultez notre Instagram pour les horaires spéciaux.", "Hours may vary on holidays. Check our Instagram for special hours.")}</p>
    </div>
    <div class="visit__map">${mapBlock(lang)}</div>
  </div>
</section>
`;

  return {
    title: L("Contact, heures et adresse", "Contact, hours & address"),
    description: L(
      "L’Extension Café Lounge, 200, rue Bernard Ouest, Montréal (Mile End). Heures d’ouverture, téléphone 514 522-0737, itinéraire et Instagram.",
      "L’Extension Café Lounge, 200 Bernard St. West, Montréal (Mile End). Opening hours, phone 514-522-0737, directions and Instagram."
    ),
    body,
  };
}
