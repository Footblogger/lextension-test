import { site, hours } from "./data.mjs";
import { routes, href, asset, esc, brand, icon, hoursCompact, hoursJson, mapsLink, flower, miniFlower } from "./lib.mjs";

const nav = {
  fr: [["menu", "Menu"], ["contact", "Heures & contact"]],
  en: [["menu", "Menu"], ["contact", "Hours & contact"]],
};

function jsonLd(lang) {
  const dayIds = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  return {
    "@context": "https://schema.org",
    "@type": "CafeOrCoffeeShop",
    "@id": site.url + "/#cafe",
    name: site.name,
    url: site.url + "/" + (lang === "en" ? "en/" : ""),
    telephone: site.phone,
    priceRange: site.priceRange,
    servesCuisine: ["Café", "Brunch", "Cocktails"],
    image: site.url + "/assets/img/facade-soir-1200.jpg",
    sameAs: [site.instagram],
    address: {
      "@type": "PostalAddress",
      streetAddress: "200 Rue Bernard O",
      addressLocality: site.address.city,
      addressRegion: site.address.region,
      postalCode: site.address.postal,
      addressCountry: site.address.country,
    },
    hasMenu: site.url + "/" + (lang === "en" ? routes.menu.en : routes.menu.fr),
    openingHoursSpecification: hours.filter((h) => h.open).map((h) => ({
      "@type": "OpeningHoursSpecification",
      dayOfWeek: dayIds[h.day],
      opens: h.open,
      closes: h.close,
    })),
  };
}

/**
 * @param {object} o
 * @param {"fr"|"en"} o.lang
 * @param {string} o.key     clé de route (home, menu…) ou "404"
 * @param {string} o.path    chemin de sortie (ex. "en/menu/")
 * @param {string} o.title
 * @param {string} o.description
 * @param {string} o.body
 * @param {boolean} [o.abs]  liens absolus (page 404)
 */
export function layout({ lang, key, path, title, description, body, abs = false, theme = "" }) {
  const L = (fr, en) => (lang === "fr" ? fr : en);
  const h = (to) => href(path, to, { absolute: abs });
  const a = (p) => asset(path, p, abs);
  const other = lang === "fr" ? "en" : "fr";
  const altPath = routes[key] ? routes[key][other] : other === "en" ? "en/" : "";
  const homeHref = h(routes.home[lang]);
  const canonical = routes[key] ? site.url + "/" + routes[key][lang] : null;
  const fullTitle = key === "home" ? title : `${title} — L’Extension Café Lounge`;

  const navLinks = nav[lang]
    .map(([k, label]) => `<li><a href="${h(routes[k][lang])}"${k === key ? ' aria-current="page"' : ""}>${label}</a></li>`)
    .join("");

  // Barre d’actions mobile : les quatre gestes utiles quand on cherche un café sur son téléphone
  const tab = (href, ic, label, { current = false, ext = false } = {}) =>
    `<li><a class="tabbar__a" href="${href}"${current ? ' aria-current="page"' : ""}${ext ? ' target="_blank" rel="noopener"' : ""}>${icon(ic, { size: 22 })}<span>${label}</span></a></li>`;
  const tabbar = `<nav class="tabbar" aria-label="${L("Actions rapides", "Quick actions")}">
  <ul class="tabbar__list" role="list">
    ${tab(h(routes.menu[lang]), "coffee", "Menu", { current: key === "menu" })}
    ${tab(h(routes.contact[lang]), "clock", L("Heures", "Hours"), { current: key === "contact" })}
    ${tab(mapsLink(), "pin", L("Itinéraire", "Directions"), { ext: true })}
    ${tab(`tel:${site.phone}`, "phone", L("Appeler", "Call"))}
  </ul>
</nav>`;

  const langSwitch = `<a class="lang" href="${h(altPath)}" hreflang="${other}-CA" lang="${other}-CA">
<span class="sr-only">${L("English version", "Version française")}</span><span aria-hidden="true">${other.toUpperCase()}</span></a>`;

  return `<!doctype html>
<html lang="${lang}-CA" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description)}">
${canonical ? `<link rel="canonical" href="${canonical}">
<link rel="alternate" hreflang="fr-CA" href="${site.url}/${routes[key].fr}">
<link rel="alternate" hreflang="en-CA" href="${site.url}/${routes[key].en}">
<link rel="alternate" hreflang="x-default" href="${site.url}/${routes[key].fr}">` : '<meta name="robots" content="noindex">'}
<meta name="theme-color" content="#FBF4E2">
<meta property="og:type" content="website">
<meta property="og:site_name" content="L’Extension Café Lounge">
<meta property="og:locale" content="${lang}_CA">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(description)}">
${canonical ? `<meta property="og:url" content="${canonical}">` : ""}
<meta property="og:image" content="${site.url}/assets/img/og-${lang}.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="${a("favicon.svg")}" type="image/svg+xml">
<link rel="icon" href="${a("favicon-32.png")}" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="${a("apple-touch-icon.png")}">
<link rel="manifest" href="${h("site.webmanifest")}">
<link rel="preload" href="${a("fonts/fraunces.woff2")}" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="${a("fonts/dm-sans.woff2")}" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="${a("fonts/righteous.woff2")}" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="${a("css/main.css")}">
<script>document.documentElement.className=document.documentElement.className.replace('no-js','js');</script>
<script src="${a("js/main.js")}" defer></script>
<script type="application/ld+json">${JSON.stringify(jsonLd(lang))}</script>
</head>
<body class="page-${key} ${theme}">
<a class="skip" href="#contenu">${L("Aller au contenu", "Skip to content")}</a>

<header class="header" data-header>
  <div class="header__inner wrap">
    ${brand(homeHref, lang)}
    <nav class="nav" aria-label="${L("Navigation principale", "Main navigation")}">
      <ul class="nav__list">${navLinks}</ul>
    </nav>
    <div class="header__actions">
      ${langSwitch}
      <a class="btn btn--sm btn--primary header__cta" href="${mapsLink()}" target="_blank" rel="noopener">${icon("pin", { size: 16 })}<span>${L("Itinéraire", "Directions")}</span></a>
    </div>
  </div>
</header>

<main id="contenu" tabindex="-1">
${body}
</main>

<footer class="footer">
  <div class="footer__flower" aria-hidden="true">${flower({ id: "ff" })}</div>
  <div class="wrap footer__grid">
    <div class="footer__brand">
      ${brand(homeHref, lang, { cls: "brand--light" })}
      <p class="footer__pitch">${L("Un espace éthique, communautaire et convivial au cœur du Mile End.", "An ethical, community-minded and welcoming space in the heart of Mile End.")}</p>
      <a class="footer__ig" href="${site.instagram}" target="_blank" rel="noopener">${icon("instagram", { size: 20 })}<span>${site.instagramHandle}</span></a>
    </div>
    <div class="footer__col--visit">
      <h2 class="footer__h">${L("Nous visiter", "Visit us")}</h2>
      <address>
        <a href="${mapsLink()}" target="_blank" rel="noopener">${lang === "fr" ? site.address.street : site.address.streetEn}<br>${site.address.city} (${site.address.region}) ${site.address.postal}</a><br>
        <a href="tel:${site.phone}">${site.phoneDisplay}</a>
        ${site.email ? `<br><a href="mailto:${site.email}">${site.email}</a>` : ""}
      </address>
    </div>
    <div class="footer__col--hours">
      <h2 class="footer__h">${L("Heures", "Hours")}</h2>
      <ul class="footer__hours">${hoursCompact(lang)}</ul>
    </div>
    <div class="footer__col--nav">
      <h2 class="footer__h">${L("Explorer", "Explore")}</h2>
      <ul class="footer__links">
        ${nav[lang].map(([k, label]) => `<li><a href="${h(routes[k][lang])}">${label}</a></li>`).join("")}
        <li><a href="${h(altPath)}" lang="${other}-CA" hreflang="${other}-CA">${L("English", "Français")}</a></li>
      </ul>
    </div>
  </div>
  <div class="wrap footer__bottom">
    <p>© ${new Date().getFullYear()} L’Extension Café Lounge · ${L("Fait avec soin dans le Mile End", "Made with care in Mile End")} ${miniFlower("footer__mini")}</p>
    <p><a href="${h(routes.privacy[lang])}">${L("Politique de confidentialité", "Privacy policy")}</a></p>
  </div>
</footer>
${tabbar}
${hoursJson()}
</body>
</html>`;
}
