// ─────────────────────────────────────────────────────────────────────────────
//  L'EXTENSION Café Lounge — DONNÉES DU SITE
//  Ce fichier est la seule source de vérité pour les coordonnées, les horaires,
//  le menu et les avis. Modifiez ici, puis lancez `node build.mjs`.
//
//  ⚠ Tout ce qui est marqué « À VALIDER » est du contenu provisoire réaliste
//    à confirmer ou remplacer par le propriétaire avant la mise en ligne.
// ─────────────────────────────────────────────────────────────────────────────

export const site = {
  name: "L'Extension Café Lounge",
  legalName: "L'EXTENSION Cafe Lounge",
  // À VALIDER : domaine définitif (sert aux balises canonical, hreflang et au sitemap)
  url: "https://www.lextensioncafelounge.ca",
  phone: "+15145220737",
  phoneDisplay: "514 522-0737",
  // À VALIDER : adresse courriel publique (laisser vide pour la masquer)
  email: "",
  instagram: "https://www.instagram.com/lextension.cafelounge/",
  instagramHandle: "@lextension.cafelounge",
  address: {
    street: "200, rue Bernard Ouest",
    streetEn: "200 Bernard Street West",
    city: "Montréal",
    region: "QC",
    postal: "H2T 2K4",
    country: "CA",
    neighbourhood: "Mile End",
  },
  mapsQuery: "L'EXTENSION Cafe Lounge, 200 Rue Bernard O, Montréal, QC H2T 2K4",
  priceRange: "$$",
  rating: { value: "4,7", valueEn: "4.7", count: 21 },
};

// À VALIDER : horaires provisoires. 0 = dimanche … 6 = samedi.
// `null` = fermé. Format 24 h « HH:MM ».
export const hours = [
  { day: 0, open: "10:00", close: "18:00" },
  { day: 1, open: "09:00", close: "18:00" },
  { day: 2, open: "09:00", close: "18:00" },
  { day: 3, open: "09:00", close: "18:00" },
  { day: 4, open: "09:00", close: "23:00" },
  { day: 5, open: "09:00", close: "23:00" },
  { day: 6, open: "10:00", close: "23:00" },
];

// Avis Google publics (extraits fidèles).
export const reviews = [
  {
    author: "Stephen Willcock",
    fr: "Ambiance charmante, personnel excellent, café superbe, nourriture délicieuse.",
    en: "Lovely ambience, excellent staff, superb coffee, delicious food.",
    original: "en",
  },
  {
    author: "Benoit Lesage",
    fr: "Une très belle ambiance et un super service, avec le meilleur mac and cheese qui soit !",
    en: "Really nice atmosphere and service with the best mac and cheese ever!",
    original: "en",
  },
  {
    author: "Lykkå Village",
    fr: "Très mignon, des gens formidables et de la bonne bouffe.",
    en: "Very cute, great people and food.",
    original: "en",
  },
];

// ─── MENU (À VALIDER : plats, descriptions et prix provisoires) ─────────────
// tags : v = végétarien, vg = végane, sg = sans gluten, sig = signature
export const menu = [
  {
    id: "cafe",
    fr: { title: "Café", note: "Lait d’avoine ou d’amande +0,75 $ · Shot supplémentaire +1 $" },
    en: { title: "Coffee", note: "Oat or almond milk +$0.75 · Extra shot +$1" },
    items: [
      { fr: ["Espresso", ""], en: ["Espresso", ""], price: 3.25 },
      { fr: ["Allongé", ""], en: ["Americano", ""], price: 3.75 },
      { fr: ["Macchiato", ""], en: ["Macchiato", ""], price: 3.75 },
      { fr: ["Cortado", ""], en: ["Cortado", ""], price: 4.25 },
      { fr: ["Cappuccino", ""], en: ["Cappuccino", ""], price: 4.75 },
      { fr: ["Latte", ""], en: ["Latte", ""], price: 5.25 },
      { fr: ["Moka", "Chocolat noir, espresso, lait vapeur"], en: ["Mocha", "Dark chocolate, espresso, steamed milk"], price: 5.75 },
      { fr: ["Latte à l’érable", "Sirop d’érable du Québec, cannelle"], en: ["Maple latte", "Québec maple syrup, cinnamon"], price: 6.0, tags: ["sig"] },
      { fr: ["Café filtre", "Remplissage à volonté sur place"], en: ["Filter coffee", "Free refills when dining in"], price: 3.25 },
    ],
  },
  {
    id: "the",
    fr: { title: "Thés & cie", note: "Thés en feuilles, infusés à la bonne température" },
    en: { title: "Tea & more", note: "Loose-leaf teas, brewed at the right temperature" },
    items: [
      { fr: ["Thé ou tisane", "Noir, vert, rooibos, camomille…"], en: ["Tea or herbal tea", "Black, green, rooibos, chamomile…"], price: 3.75, tags: ["vg"] },
      { fr: ["Chaï latte", "Épices maison"], en: ["Chai latte", "House spice blend"], price: 5.5 },
      { fr: ["Matcha latte", "Matcha de cérémonie"], en: ["Matcha latte", "Ceremonial-grade matcha"], price: 6.0 },
      { fr: ["London Fog", "Earl Grey, vanille, lait moussé"], en: ["London Fog", "Earl Grey, vanilla, foamed milk"], price: 5.5 },
      { fr: ["Chocolat chaud", "Guimauve sur demande"], en: ["Hot chocolate", "Marshmallow on request"], price: 4.75 },
      { fr: ["Limonade maison", "Citron, menthe fraîche"], en: ["House lemonade", "Lemon, fresh mint"], price: 4.5, tags: ["vg"] },
    ],
  },
  {
    id: "cocktails",
    fr: { title: "Cocktails", note: "Servis à partir de 15 h" },
    en: { title: "Cocktails", note: "Served from 3 p.m." },
    items: [
      { fr: ["Fleur de 70", "Gin, hibiscus, citron, blanc d’œuf"], en: ["Flower of ’70", "Gin, hibiscus, lemon, egg white"], price: 14, tags: ["sig"] },
      { fr: ["Le Bernard", "Bourbon, érable, amer à l’orange"], en: ["The Bernard", "Bourbon, maple, orange bitters"], price: 15 },
      { fr: ["Espresso martini", "Vodka, espresso de la maison, café liqueur"], en: ["Espresso martini", "Vodka, house espresso, coffee liqueur"], price: 15 },
      { fr: ["Spritz du Mile End", "Apéritif amer, mousseux, soda, orange"], en: ["Mile End spritz", "Bitter aperitif, sparkling wine, soda, orange"], price: 13 },
      { fr: ["Negroni", "Gin, vermouth rouge, amer"], en: ["Negroni", "Gin, red vermouth, bitter"], price: 14 },
    ],
  },
  {
    id: "mocktails",
    fr: { title: "Mocktails", note: "Tout le plaisir, zéro alcool" },
    en: { title: "Mocktails", note: "All of the fun, none of the alcohol" },
    items: [
      { fr: ["Jardin d’hibiscus", "Hibiscus, lime, gingembre, soda"], en: ["Hibiscus garden", "Hibiscus, lime, ginger, soda"], price: 8, tags: ["vg"] },
      { fr: ["Faux-spritz", "Apéritif sans alcool, pamplemousse, romarin"], en: ["No-spritz", "Alcohol-free aperitif, grapefruit, rosemary"], price: 9, tags: ["vg"] },
      { fr: ["Cold brew tonic", "Cold brew, tonique, zeste d’orange"], en: ["Cold brew tonic", "Cold brew, tonic, orange zest"], price: 7, tags: ["vg"] },
    ],
  },
  {
    id: "bieres",
    fr: { title: "Bières & vins", note: "Sélection québécoise, en rotation" },
    en: { title: "Beer & wine", note: "Rotating Québec selection" },
    items: [
      { fr: ["Bière de microbrasserie (pinte)", "Demandez la sélection du moment"], en: ["Craft beer (pint)", "Ask about the current selection"], price: 9 },
      { fr: ["Bière en canette", "Blonde, IPA, sure ou rousse"], en: ["Canned beer", "Lager, IPA, sour or red ale"], price: 8 },
      { fr: ["Verre de vin", "Rouge, blanc ou orange"], en: ["Glass of wine", "Red, white or orange"], price: 11 },
      { fr: ["Cidre du Québec", ""], en: ["Québec cider", ""], price: 9 },
    ],
  },
  {
    id: "midi",
    fr: { title: "Déjeuner & midi", note: "Servi jusqu’à 15 h, sauf le mac & cheese, servi en tout temps" },
    en: { title: "Breakfast & lunch", note: "Until 3 p.m., except the mac & cheese, served all day" },
    items: [
      { fr: ["Le fameux mac & cheese", "Trois fromages québécois, chapelure dorée"], en: ["The famous mac & cheese", "Three Québec cheeses, golden crumb"], price: 17, tags: ["sig", "v"] },
      { fr: ["… version gratinée au bacon", ""], en: ["… with bacon, extra gratiné", ""], price: 20 },
      { fr: ["Grilled cheese", "Cheddar vieilli, pain au levain, soupe du jour"], en: ["Grilled cheese", "Aged cheddar, sourdough, soup of the day"], price: 15, tags: ["v"] },
      { fr: ["Bol du moment", "Grains, légumes de saison, sauce tahini"], en: ["Seasonal bowl", "Grains, seasonal vegetables, tahini dressing"], price: 16, tags: ["vg"] },
      { fr: ["Tartine avocat", "Levain, radis, graines, œuf mollet en option"], en: ["Avocado toast", "Sourdough, radish, seeds, soft egg optional"], price: 13, tags: ["v"] },
      { fr: ["Soupe du jour", ""], en: ["Soup of the day", ""], price: 7, tags: ["v"] },
    ],
  },
  {
    id: "petites-faims",
    fr: { title: "Petites faims & apéro", note: "Parfait pour le 5 à 7" },
    en: { title: "Snacks & apéro", note: "Perfect for happy hour" },
    items: [
      { fr: ["Planche de l’Extension", "Fromages et charcuteries du Québec, marinades, pain"], en: ["L’Extension board", "Québec cheeses and charcuterie, pickles, bread"], price: 22, tags: ["sig"] },
      { fr: ["Houmous & pita grillée", ""], en: ["Hummus & grilled pita", ""], price: 10, tags: ["vg"] },
      { fr: ["Olives marinées", "Agrumes et herbes"], en: ["Marinated olives", "Citrus and herbs"], price: 6, tags: ["vg", "sg"] },
      { fr: ["Croquettes de mac & cheese", "Mayo épicée"], en: ["Mac & cheese bites", "Spicy mayo"], price: 11, tags: ["v"] },
    ],
  },
  {
    id: "sucre",
    fr: { title: "Le goûter", note: "Douceurs du jour au comptoir" },
    en: { title: "Sweet treats", note: "Daily sweets at the counter" },
    items: [
      { fr: ["Croissant", ""], en: ["Croissant", ""], price: 3.75, tags: ["v"] },
      { fr: ["Muffin du jour", ""], en: ["Muffin of the day", ""], price: 3.75, tags: ["v"] },
      { fr: ["Biscuit géant", "Chocolat noir et fleur de sel"], en: ["Giant cookie", "Dark chocolate and sea salt"], price: 3.5, tags: ["v"] },
      { fr: ["Pouding chômeur", "Le classique québécois, sirop d’érable"], en: ["Pouding chômeur", "The Québec classic, maple syrup"], price: 7, tags: ["v"] },
      { fr: ["Carré aux dattes", ""], en: ["Date square", ""], price: 4, tags: ["vg"] },
    ],
  },
];
