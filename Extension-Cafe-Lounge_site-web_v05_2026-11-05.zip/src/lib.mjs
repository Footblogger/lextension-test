// Utilitaires de génération (aucune dépendance externe).
import { site, hours } from "./data.mjs";

// ─── Routes ──────────────────────────────────────────────────────────────────
export const routes = {
  home: { fr: "", en: "en/" },
  menu: { fr: "menu/", en: "en/menu/" },
  contact: { fr: "contact/", en: "en/contact/" },
  privacy: { fr: "confidentialite/", en: "en/privacy/" },
};

/** Lien relatif depuis la page courante (`from` = chemin de route, ex. "en/menu/"). */
export function href(from, to, { absolute = false } = {}) {
  if (absolute) return "/" + to;
  const depth = from.split("/").filter(Boolean).length;
  const prefix = depth ? "../".repeat(depth) : "./";
  const out = prefix + to;
  return out === "./" ? "./" : out.replace(/^\.\/(?=.)/, "./");
}

export const asset = (from, p, abs) => href(from, "assets/" + p, { absolute: abs });

// ─── Texte ───────────────────────────────────────────────────────────────────
export const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/**
 * Titre découpé par mots pour l'animation d'apparition.
 * Les mots entourés d'astérisques passent en italique (*votre salon*).
 * Le texte complet reste lisible par les lecteurs d'écran via aria-label.
 */
export function splitTitle(text, { tag = "h1", cls = "" } = {}) {
  const plain = text.replace(/\*/g, "");
  let italic = false;
  let i = 0;
  const words = text.split(/\s+/).map((w) => {
    let open = false, close = false;
    if (w.startsWith("*")) { italic = true; open = true; w = w.slice(1); }
    if (w.endsWith("*") || w.match(/\*[.,!?…]$/)) { close = true; w = w.replace("*", ""); }
    const inner = `<span class="split__w" style="--i:${i++}">${italic ? `<em>${esc(w)}</em>` : esc(w)}</span>`;
    if (close) italic = false;
    void open;
    return `<span class="split__m">${inner}</span>`;
  });
  return `<${tag} class="split ${cls}" aria-label="${esc(plain)}"><span aria-hidden="true">${words.join(" ")}</span></${tag}>`;
}

/** Paragraphe dont les mots s'illuminent au défilement. */
export function inkWords(text) {
  return text
    .split(/\s+/)
    .map((w) => `<span class="ink__w">${esc(w)}</span>`)
    .join(" ");
}

// ─── Prix & horaires ─────────────────────────────────────────────────────────
export function price(n, lang) {
  const s = Number.isInteger(n) ? String(n) : n.toFixed(2);
  return lang === "fr" ? `${s.replace(".", ",")} $` : `$${s}`;
}

export const dayNames = {
  fr: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"],
  en: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
};
const dayShort = {
  fr: ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."],
  en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
};

export function time(hhmm, lang) {
  const [h, m] = hhmm.split(":").map(Number);
  if (lang === "fr") return `${h} h${m ? String(m).padStart(2, "0") : ""}`;
  const suffix = h >= 12 && h < 24 ? "p.m." : "a.m.";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}${m ? ":" + String(m).padStart(2, "0") : ""} ${suffix}`;
}

export function range(o, lang) {
  if (!o.open) return lang === "fr" ? "Fermé" : "Closed";
  return `${time(o.open, lang)} – ${time(o.close, lang)}`;
}

const mondayFirst = [1, 2, 3, 4, 5, 6, 0];

/** Tableau complet (7 jours, lundi en premier), jour courant mis en évidence par JS. */
export function hoursTable(lang) {
  const rows = mondayFirst
    .map((d) => {
      const o = hours.find((h) => h.day === d) || {};
      return `<tr data-day="${d}"><th scope="row">${dayNames[lang][d]}</th><td>${range(o, lang)}</td></tr>`;
    })
    .join("");
  return `<table class="hours"><caption class="sr-only">${lang === "fr" ? "Heures d’ouverture" : "Opening hours"}</caption><tbody>${rows}</tbody></table>`;
}

/** Version groupée compacte (ex. « lun. – mer. 9 h – 18 h »). */
export function hoursCompact(lang) {
  const groups = [];
  for (const d of mondayFirst) {
    const o = hours.find((h) => h.day === d) || {};
    const r = range(o, lang);
    const last = groups[groups.length - 1];
    if (last && last.r === r) last.to = d;
    else groups.push({ from: d, to: d, r });
  }
  return groups
    .map((g) => {
      const days = g.from === g.to ? dayShort[lang][g.from] : `${dayShort[lang][g.from]} – ${dayShort[lang][g.to]}`;
      return `<li><span>${days}</span><span>${g.r}</span></li>`;
    })
    .join("");
}

export const hoursJson = () =>
  `<script type="application/json" id="hours-data">${JSON.stringify(hours)}</script>`;

export const mapsLink = () =>
  "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(site.mapsQuery);
export const mapsEmbed = () =>
  "https://www.google.com/maps?output=embed&q=" + encodeURIComponent(site.mapsQuery);

// ─── Icônes (tracés Lucide, licence ISC) ─────────────────────────────────────
const paths = {
  arrow: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  pin: '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  instagram: '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><path d="M17.5 6.5h.01"/>',
  coffee: '<path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/><path d="M6 2v2"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  wine: '<path d="M8 22h8"/><path d="M7 10h10"/><path d="M12 15v7"/><path d="M12 15a5 5 0 0 0 5-5c0-2-.5-4-2-8H9c-1.5 4-2 6-2 8a5 5 0 0 0 5 5Z"/>',
  utensils: '<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>',
  cookie: '<path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/><path d="M8.5 8.5v.01"/><path d="M16 15.5v.01"/><path d="M12 12v.01"/><path d="M11 17v.01"/><path d="M7 14v.01"/>',
  star: '<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
  calendar: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  cake: '<path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8"/><path d="M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1"/><path d="M2 21h20"/><path d="M7 8v3"/><path d="M12 8v3"/><path d="M17 8v3"/><path d="M7 4h.01"/><path d="M12 4h.01"/><path d="M17 4h.01"/>',
  briefcase: '<path d="M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/><rect width="20" height="14" x="2" y="6" rx="2"/>',
  palette: '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
  book: '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
  wifi: '<path d="M12 20h.01"/><path d="M2 8.82a15 15 0 0 1 20 0"/><path d="M5 12.859a10 10 0 0 1 14 0"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/>',
  recycle: '<path d="M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5"/><path d="M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775l-1.226-2.12"/><path d="m14 16-3 3 3 3"/><path d="M8.293 13.596 7.196 9.5 3.1 10.598"/><path d="m9.344 5.811 1.093-1.892A1.83 1.83 0 0 1 11.985 3a1.784 1.784 0 0 1 1.546.888l3.943 6.843"/><path d="m13.378 9.633 4.096 1.098 1.097-4.096"/>',
};

export function icon(name, { size = 20, cls = "icon", label = "" } = {}) {
  const a11y = label ? `role="img" aria-label="${esc(label)}"` : 'aria-hidden="true" focusable="false"';
  return `<svg class="${cls}" ${a11y} width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">${paths[name]}</svg>`;
}

// ─── Fleur signature (SVG vectoriel recréé d'après le motif de la vitrine) ──
function flowerGeometry() {
  const pts = [];
  for (let k = 0; k < 8; k++) {
    for (const [da, r] of [[-11, 26], [0, 60], [11, 26], [22.5, 40]]) {
      const t = ((k * 45 + da - 90) * Math.PI) / 180;
      pts.push(`${(r * Math.cos(t)).toFixed(1)},${(r * Math.sin(t)).toFixed(1)}`);
    }
  }
  let stamens = "";
  for (let k = 0; k < 8; k++) {
    const a = ((k * 45 + 22.5 - 90) * Math.PI) / 180;
    const c = (r) => [(r * Math.cos(a)).toFixed(1), (r * Math.sin(a)).toFixed(1)];
    const [x1, y1] = c(25), [x2, y2] = c(32.5), [cx, cy] = c(35.5);
    stamens += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/><circle cx="${cx}" cy="${cy}" r="3.3"/>`;
  }
  return { star: pts.join(" "), stamens };
}
const geo = flowerGeometry();
const PETAL = "M0-10L-17.04-60.23A18 18 0 1 1 17.04-60.23Z";

/**
 * Fleur rétro. `bloom` = animation d'éclosion au chargement,
 * `spin` = rotation lente continue (désactivée si mouvement réduit).
 */
export function flower({ cls = "", bloom = false, spin = false, bg = true, id = "f" } = {}) {
  const ring = (layer) =>
    Array.from({ length: 8 }, (_, k) => `<use href="#${id}-p" class="flower__petal" style="--k:${k}" transform="rotate(${k * 45})"/>`).join("");
  return `<svg class="flower ${bloom ? "flower--bloom" : ""} ${spin ? "flower--spin" : ""} ${cls}" viewBox="-100 -100 200 200" aria-hidden="true" focusable="false">
<defs><path id="${id}-p" d="${PETAL}"/></defs>
${bg ? '<circle class="flower__bg" r="99"/>' : ""}
<g class="flower__rot">
<g class="flower__layer flower__layer--o">${ring()}</g>
<g class="flower__layer flower__layer--c">${ring()}</g>
<g class="flower__layer flower__layer--b">${ring()}</g>
<polygon class="flower__star" points="${geo.star}"/>
<g class="flower__stamens">${geo.stamens}</g>
<circle class="flower__heart" r="25"/>
</g>
</svg>`;
}

/** Petite fleur simplifiée (séparateurs, « o » du logo). */
export function miniFlower(cls = "") {
  const petals = Array.from({ length: 8 }, (_, k) => `<ellipse cx="0" cy="-27" rx="13" ry="21" transform="rotate(${k * 45})"/>`).join("");
  return `<svg class="mini-flower ${cls}" viewBox="-50 -50 100 100" aria-hidden="true" focusable="false"><g class="mini-flower__p">${petals}</g><circle class="mini-flower__c" r="14"/></svg>`;
}

/** Mot-symbole « L'extension · Café • Lounge » (approximation à remplacer par le logo vectoriel officiel). */
export function brand(homeHref, lang, { cls = "" } = {}) {
  return `<a class="brand ${cls}" href="${homeHref}" aria-label="L’Extension Café Lounge — ${lang === "fr" ? "accueil" : "home"}">
<span class="brand__word" aria-hidden="true">L’extensi${miniFlower("brand__o")}n</span>
<span class="brand__tag" aria-hidden="true">Café <i></i> Lounge</span>
</a>`;
}

/** Image responsive AVIF/WebP/JPEG. */
export function picture(from, name, widths, { alt, sizes, cls = "", eager = false, ratio, abs = false, art = null }) {
  const set = (ext, n = name, ws = widths) => ws.map((w) => `${asset(from, `img/${n}-${w}.${ext}`, abs)} ${w}w`).join(", ");
  const largest = widths[widths.length - 1];
  const [rw, rh] = ratio;
  // art = { name, widths, media, sizes } : recadrage dédié aux petits écrans
  const artSources = art
    ? ["avif", "webp"].map((ext) => `<source media="${art.media}" type="image/${ext}" srcset="${set(ext, art.name, art.widths)}" sizes="${art.sizes}">`).join("\n")
    : "";
  return `<picture class="${cls}">
${artSources}
<source type="image/avif" srcset="${set("avif")}" sizes="${sizes}">
<source type="image/webp" srcset="${set("webp")}" sizes="${sizes}">
<img src="${asset(from, `img/${name}-${largest}.jpg`, abs)}" srcset="${set("jpg")}" sizes="${sizes}" width="${rw}" height="${rh}" alt="${esc(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">
</picture>`;
}

/** Texte circulaire rotatif (style autocollant rétro). */
export function ringText(text, id) {
  return `<svg class="ring-text" viewBox="0 0 200 200" aria-hidden="true" focusable="false">
<defs><path id="${id}" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0"/></defs>
<text><textPath href="#${id}" textLength="485">${esc(text)}</textPath></text>
</svg>`;
}
