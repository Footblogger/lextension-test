/* L’Extension Café Lounge — interactions (aucune dépendance) */
(() => {
  "use strict";

  const doc = document.documentElement;
  const FR = (doc.lang || "fr").slice(0, 2) === "fr";
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const hasIO = "IntersectionObserver" in window;

  /* ── En-tête : fond au défilement, masqué en descendant ─────────────────── */
  const header = $("[data-header]");
  let lastY = window.scrollY;
  let ticking = false;
  const onScroll = () => {
    const y = window.scrollY;
    header.classList.toggle("is-scrolled", y > 12);
    const hide = y > 260 && y > lastY + 4;
    const show = y < lastY - 4 || y <= 260;
    if (hide) { header.classList.add("is-hidden"); doc.classList.add("header-hidden"); }
    else if (show) { header.classList.remove("is-hidden"); doc.classList.remove("header-hidden"); }
    lastY = y;
    ticking = false;
  };
  window.addEventListener("scroll", () => {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();
  header.addEventListener("focusin", () => { header.classList.remove("is-hidden"); doc.classList.remove("header-hidden"); });

  /* ── Manifeste : les mots s’allument au fil de la lecture ──────────────── */
  const ink = $("[data-ink]");
  if (ink) {
    const words = $$(".ink__w", ink);
    if (reduce.matches || !hasIO) {
      words.forEach((w) => w.classList.add("on"));
    } else {
      let active = false, raf = 0;
      const update = () => {
        raf = 0;
        const r = ink.getBoundingClientRect();
        const vh = window.innerHeight;
        const start = vh * 0.88, end = vh * 0.42;
        const p = Math.min(1, Math.max(0, (start - r.top) / (start - end + r.height * 0.6)));
        const n = Math.round(p * words.length);
        words.forEach((w, i) => w.classList.toggle("on", i < n));
      };
      const tick = () => { if (active && !raf) raf = requestAnimationFrame(update); };
      new IntersectionObserver(([en]) => { active = en.isIntersecting; tick(); }).observe(ink);
      window.addEventListener("scroll", tick, { passive: true });
      window.addEventListener("resize", tick, { passive: true });
    }
  }

  /* ── Pause des animations hors écran (batterie) ────────────────────────── */
  if (hasIO) {
    const pio = new IntersectionObserver((entries) => {
      entries.forEach((en) => en.target.classList.toggle("is-offscreen", !en.isIntersecting));
    });
    $$(".marquee, .hero__badge, .map__pin").forEach((el) => pio.observe(el));
  }

  /* ── Heures : « Ouvert maintenant » à l’heure de Montréal ──────────────── */
  const hoursEl = $("#hours-data");
  if (hoursEl) {
    let hours = [];
    try { hours = JSON.parse(hoursEl.textContent); } catch (e) { /* données absentes */ }
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Montreal", weekday: "short", hour: "numeric", minute: "numeric", hourCycle: "h23" }).formatToParts(new Date());
    const get = (t) => (parts.find((p) => p.type === t) || {}).value;
    const day = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(get("weekday"));
    const now = parseInt(get("hour"), 10) * 60 + parseInt(get("minute"), 10);
    const mins = (s) => { const [h, m] = s.split(":").map(Number); return h * 60 + m; };
    const fmtTime = (s) => {
      const [h, m] = s.split(":").map(Number);
      if (FR) return `${h} h${m ? String(m).padStart(2, "0") : ""}`;
      const h12 = h % 12 === 0 ? 12 : h % 12;
      return `${h12}${m ? ":" + String(m).padStart(2, "0") : ""} ${h >= 12 ? "p.m." : "a.m."}`;
    };
    const names = FR
      ? ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"]
      : ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const byDay = (d) => hours.find((h) => h.day === d && h.open);

    let html = "", open = false;
    const today = byDay(day);
    if (today && now >= mins(today.open) && now < mins(today.close)) {
      open = true;
      const left = mins(today.close) - now;
      html = left <= 60
        ? (FR ? `<strong>Ferme bientôt</strong> · à ${fmtTime(today.close)}` : `<strong>Closing soon</strong> · at ${fmtTime(today.close)}`)
        : (FR ? `<strong>Ouvert maintenant</strong> · jusqu’à ${fmtTime(today.close)}` : `<strong>Open now</strong> · until ${fmtTime(today.close)}`);
    } else if (today && now < mins(today.open)) {
      html = FR ? `<strong>Fermé</strong> · ouvre aujourd’hui à ${fmtTime(today.open)}` : `<strong>Closed</strong> · opens today at ${fmtTime(today.open)}`;
    } else {
      for (let i = 1; i <= 7; i++) {
        const d = (day + i) % 7, o = byDay(d);
        if (o) {
          const when = i === 1 ? (FR ? "demain" : "tomorrow") : names[d];
          html = FR ? `<strong>Fermé</strong> · ouvre ${when} à ${fmtTime(o.open)}` : `<strong>Closed</strong> · opens ${when} at ${fmtTime(o.open)}`;
          break;
        }
      }
    }
    if (html && day >= 0) {
      $$("[data-status]").forEach((el) => { el.innerHTML = `<span>${html}</span>`; el.classList.toggle("is-open", open); el.hidden = false; });
    }
    $$(`.hours tr[data-day="${day}"]`).forEach((tr) => {
      tr.classList.add("is-today");
      const th = $("th", tr);
      if (th) th.insertAdjacentHTML("beforeend", `<span class="today-tag">${FR ? "Aujourd’hui" : "Today"}</span>`);
    });
  }

  /* ── Carte Google chargée seulement au clic ────────────────────────────── */
  $$("[data-map]").forEach((map) => {
    const btn = $("[data-map-load]", map);
    if (!btn) return;
    btn.addEventListener("click", () => {
      const f = document.createElement("iframe");
      f.src = map.dataset.src;
      f.title = map.dataset.title;
      f.loading = "lazy";
      f.referrerPolicy = "no-referrer-when-downgrade";
      f.allowFullscreen = true;
      f.addEventListener("load", () => map.classList.add("is-loaded"), { once: true });
      map.appendChild(f);
      setTimeout(() => map.classList.add("is-loaded"), 2500);
      f.focus();
    }, { once: true });
  });

  /* ── Menu : catégorie active (scrollspy) ───────────────────────────────── */
  const menuNav = $("[data-menunav]");
  if (menuNav && hasIO) {
    const list = $(".menu-nav__list", menuNav);
    const chips = $$("[data-spy]", menuNav);
    const setActive = (id) => {
      chips.forEach((c) => {
        if (c.dataset.spy === id) {
          if (c.getAttribute("aria-current") === "true") return;
          c.setAttribute("aria-current", "true");
          const left = c.offsetLeft - (list.clientWidth - c.offsetWidth) / 2;
          list.scrollTo({ left, behavior: reduce.matches ? "auto" : "smooth" });
        } else c.removeAttribute("aria-current");
      });
    };
    const sio = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) setActive(en.target.id); });
    }, { rootMargin: "-35% 0px -60% 0px" });
    chips.forEach((c) => { const s = document.getElementById(c.dataset.spy); if (s) sio.observe(s); });
    const firstSec = document.getElementById(chips[0].dataset.spy);
    window.addEventListener("scroll", () => {
      if (firstSec && firstSec.getBoundingClientRect().top > window.innerHeight * 0.4) setActive(chips[0].dataset.spy);
    }, { passive: true });
  }
})();
