// Génère le site statique dans ./dist — usage : node build.mjs
import { rm, mkdir, writeFile, cp } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { site } from "./src/data.mjs";
import { routes } from "./src/lib.mjs";
import { layout } from "./src/layout.mjs";
import home from "./src/pages/home.mjs";
import menu from "./src/pages/menu.mjs";
import contact from "./src/pages/contact.mjs";
import privacy from "./src/pages/privacy.mjs";
import notFound from "./src/pages/notfound.mjs";

// Typographie française : espaces insécables avant ? ! ; : et dans les guillemets.
// Appliqué au texte seulement (hors balises, scripts et JSON-LD).
function frenchSpacing(html) {
  return html.replace(/(<script[\s\S]*?<\/script>)|(<[^>]+>)|([^<]+)/g, (m, script, tag, text) => {
    if (!text) return m;
    return text
      .replace(/ ([?!;])/g, "\u202f$1")
      .replace(/ :(?=\s|$)/g, "\u00a0:")
      .replace(/« /g, "«\u00a0")
      .replace(/ »/g, "\u00a0»");
  });
}

const ROOT = dirname(fileURLToPath(import.meta.url));
const DIST = join(ROOT, "dist");
const pages = { home, menu, contact, privacy };

await rm(DIST, { recursive: true, force: true });
await mkdir(DIST, { recursive: true });
await cp(join(ROOT, "src/assets"), join(DIST, "assets"), { recursive: true });
await cp(join(ROOT, "src/static"), DIST, { recursive: true });

let count = 0;
for (const [key, render] of Object.entries(pages)) {
  for (const lang of ["fr", "en"]) {
    const path = routes[key][lang];
    const { title, description, body } = render(lang, path);
    let html = layout({ lang, key, path, title, description, body });
    if (lang === "fr") html = frenchSpacing(html);
    const file = join(DIST, path, "index.html");
    await mkdir(dirname(file), { recursive: true });
    await writeFile(file, html);
    count++;
  }
}

const nf = notFound();
await writeFile(join(DIST, "404.html"), frenchSpacing(layout({ lang: "fr", key: "404", path: "", abs: true, ...nf })));
count++;

// sitemap.xml avec alternatives hreflang
const today = new Date().toISOString().slice(0, 10);
const urls = Object.keys(pages)
  .flatMap((k) =>
    ["fr", "en"].map(
      (lang) => `  <url>
    <loc>${site.url}/${routes[k][lang]}</loc>
    <lastmod>${today}</lastmod>
    <xhtml:link rel="alternate" hreflang="fr-CA" href="${site.url}/${routes[k].fr}"/>
    <xhtml:link rel="alternate" hreflang="en-CA" href="${site.url}/${routes[k].en}"/>
  </url>`
    )
  )
  .join("\n");
await writeFile(
  join(DIST, "sitemap.xml"),
  `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urls}
</urlset>
`
);
await writeFile(join(DIST, "robots.txt"), `User-agent: *\nAllow: /\n\nSitemap: ${site.url}/sitemap.xml\n`);

console.log(`✓ ${count} pages générées dans dist/`);
